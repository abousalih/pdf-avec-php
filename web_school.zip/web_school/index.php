
<?php
    header("location:admin/dashboard/dashboard.php");