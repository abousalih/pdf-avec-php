<?php
$pdo = new PDO("mysql: host=localhost;	dbname=ecoledb",	"root", "");
//echo "connexion :OK";
?>
